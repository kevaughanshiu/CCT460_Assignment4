Thanks for installing our Social Media Hub!

Once you've activated the plugin:

1. Click the 'Group 9 Plugin' button along the side of your dashboard
2. In the settings, type your username for your various social media accounts*
3. Choose between the two styles of icons for each site.
4. To use these buttons on any post or page, use the shortcode [kase_short]

* Type in your username as if it were part of the url. 
Ex: www.twitter.com/_______, or  __________.tumblr.com

Group members:
Joe Measures
Sabrina Li
Kevaughan Shiu

URL: phoenix.sheridanc.on.ca/~ccit2646
Github: https://github.com/kevaughanshiu/CCT460_Assignment4